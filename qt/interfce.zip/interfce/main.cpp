
cout <<"Im salma and Ill make it">>
cout <<"Im the best <3">>
